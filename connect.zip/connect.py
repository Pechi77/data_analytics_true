from flask import Flask
from flask.ext.mongoalchemy import MongoAlchemy

app=Flask(__name__)

app.config['MONGOALCHEMY_DATABASE'] = 'test_pechi'
app.config['MONGOALCHEMY_CONNECTION_STRING'] ='mongodb://pechi:pechi123@ds127341.mlab.com:27341/test_pechi'

db=MongoAlchemy(app)

class user(db.Document):
	name=db.StringField()
	password=db.StringField()

