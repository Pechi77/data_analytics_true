"""This package contains some deprecated implementations of algorithm, will be removed soon."""
