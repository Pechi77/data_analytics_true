from unittest import TestCase
from semanticpy.transform.lda import LDA

class LDATest(TestCase):
    def it_should_do_lsa_test(self):
        pass